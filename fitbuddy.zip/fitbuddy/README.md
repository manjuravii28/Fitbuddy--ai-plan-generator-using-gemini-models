# FitBuddy - AI Fitness Plan Generator (Gemini + FastAPI)

Personalised 7-day workout plans, nutrition/recovery tips and feedback-based plan updates,
powered by Google Gemini (Pro for plans, Flash for tips), FastAPI, SQLAlchemy/SQLite and Jinja2.

## Project structure
```
fitbuddy/
├── app/
│   ├── main.py                    # FastAPI app, static files, DB init
│   ├── routes.py                  # HTML pages + JSON API
│   ├── config.py                  # env/.env settings
│   ├── schemas.py                 # Pydantic: UserInput, FeedbackRequest, PlanResponse
│   ├── database.py                # SQLAlchemy models + save_user/save_plan/update_plan/...
│   ├── ai_client.py               # shared Gemini wrapper
│   ├── gemini_generator.py        # generate_workout_gemini()  (Gemini Pro)
│   ├── gemini_flash_generator.py  # generate_nutrition_tip_with_flash()  (Gemini Flash)
│   ├── updated_plan.py            # update_workout_plan()  (Gemini Pro)
│   └── fallback.py                # offline templates when no API key / API error
├── templates/   base.html, index.html, result.html, all_users.html
├── static/      css/style.css, images/   (optional: add gym.jpg as the background)
├── tests/       pytest suite (runs offline)
├── requirements.txt  .env.example  .gitignore
```

## Setup
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # then put your GOOGLE_API_KEY in .env
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000 (app) and http://127.0.0.1:8000/docs (API docs).

Without a `GOOGLE_API_KEY` the app still works using built-in offline templates
(the result page shows a badge), which is handy for demos and tests.

## Routes
| Method | Path | Purpose |
|---|---|---|
| GET | `/` | Input form |
| POST | `/generate-workout` | Generate plan + tip, save user and plan |
| POST | `/submit-feedback` | Revise plan with AI using feedback |
| GET | `/plan/{user_id}` | View a saved plan |
| GET | `/view-all-users` | Admin dashboard (original vs updated plans, delete) |
| POST | `/api/generate-workout`, `/api/submit-feedback` | JSON equivalents |
| GET | `/api/users`, `/health` | Admin list / health check |

## Configuration (.env)
- `GOOGLE_API_KEY` - Gemini key from https://aistudio.google.com/apikey
- `GEMINI_PRO_MODEL` / `GEMINI_FLASH_MODEL` - default `gemini-2.5-pro` / `gemini-2.5-flash`
- `DATABASE_URL` - default `sqlite:///./fitbuddy.db`
- `ADMIN_KEY` - if set, the dashboard needs `/view-all-users?key=<ADMIN_KEY>`

## Tests
```bash
pytest -q
```

## Notes
- Gemini 1.5 models from the original design have been retired by Google, so the models are
  configurable and default to current ones. The SDK is `google-genai` (the older
  `google-generativeai` package is deprecated).
- Re-submitting an existing User ID resets that user's profile and plans.
- Feedback is applied to the latest version of the plan, so changes accumulate.
- Educational project: plans are general fitness information, not medical advice.
