"""FitBuddy - AI Fitness Plan Generator."""
