"""Thin wrapper around the Gemini SDK shared by all generators.

If no API key is configured (or a call fails) callers can fall back to the
offline generators in `fallback.py`, so the app stays usable for demos/tests.
"""
import logging
from typing import Optional

from . import config

log = logging.getLogger("fitbuddy.ai")

SAFETY_NOTE = (
    "You are FitBuddy, a fitness assistant. Give general fitness information only, "
    "not medical advice. Keep exercises appropriate for the person's age and stated "
    "intensity, and remind them to consult a doctor before starting a new program "
    "if they have any health condition or injury."
)

_client = None


def ai_available() -> bool:
    return bool(config.GOOGLE_API_KEY)


def _get_client():
    global _client
    if _client is None:
        from google import genai  # imported lazily so the app starts without the SDK key

        _client = genai.Client(api_key=config.GOOGLE_API_KEY)
    return _client


def generate_text(model: str, prompt: str, temperature: float = 0.7) -> Optional[str]:
    """Return generated text, or None if unavailable / the call failed."""
    if not ai_available():
        return None
    try:
        from google.genai import types

        response = _get_client().models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=SAFETY_NOTE, temperature=temperature
            ),
        )
        text = (response.text or "").strip()
        return text or None
    except Exception as exc:  # network, quota, bad key, retired model ...
        log.warning("Gemini call failed (%s): %s", model, exc)
        return None
