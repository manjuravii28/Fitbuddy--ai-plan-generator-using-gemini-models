"""Central configuration, loaded from environment variables / .env."""
import os
from dotenv import load_dotenv

load_dotenv()

GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "").strip()
GEMINI_PRO_MODEL: str = os.getenv("GEMINI_PRO_MODEL", "gemini-2.5-pro")
GEMINI_FLASH_MODEL: str = os.getenv("GEMINI_FLASH_MODEL", "gemini-2.5-flash")
DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./fitbuddy.db")
ADMIN_KEY: str = os.getenv("ADMIN_KEY", "").strip()

GOALS = ["weight loss", "muscle gain", "general wellness", "flexibility", "endurance"]
INTENSITIES = ["low", "medium", "high"]
