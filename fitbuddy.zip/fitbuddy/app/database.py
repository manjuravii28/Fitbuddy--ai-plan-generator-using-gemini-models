"""SQLite persistence layer (SQLAlchemy 2.0 ORM).

The original plan and the feedback-updated plan are stored in separate
columns so both versions are preserved.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Iterator, Optional

from sqlalchemy import DateTime, Float, Integer, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from . import config

_connect_args = {"check_same_thread": False} if config.DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(config.DATABASE_URL, connect_args=_connect_args)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    user_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    username: Mapped[str] = mapped_column(String(80))
    age: Mapped[int] = mapped_column(Integer)
    weight: Mapped[float] = mapped_column(Float)
    goal: Mapped[str] = mapped_column(String(40))
    intensity: Mapped[str] = mapped_column(String(10))
    original_plan: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    updated_plan: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    last_feedback: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    nutrition_tip: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc).replace(tzinfo=None)
    )


def init_db() -> None:
    Base.metadata.create_all(engine)


@contextmanager
def get_session() -> Iterator[Session]:
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


# ---------------------------------------------------------------- users
def save_user(user_id: str, username: str, age: int, weight: float, goal: str, intensity: str) -> User:
    """Create the user, or reset their profile (and plans) if the ID already exists."""
    with get_session() as s:
        user = s.get(User, user_id)
        if user is None:
            user = User(user_id=user_id, username=username, age=age, weight=weight,
                        goal=goal, intensity=intensity)
            s.add(user)
        else:
            user.username, user.age, user.weight = username, age, weight
            user.goal, user.intensity = goal, intensity
            user.original_plan = user.updated_plan = user.last_feedback = user.nutrition_tip = None
        return user


def get_user(user_id: str) -> Optional[User]:
    with get_session() as s:
        return s.get(User, user_id)


def get_all_users() -> list[User]:
    with get_session() as s:
        return list(s.scalars(select(User).order_by(User.created_at.desc())))


def delete_user(user_id: str) -> bool:
    with get_session() as s:
        user = s.get(User, user_id)
        if user is None:
            return False
        s.delete(user)
        return True


# ---------------------------------------------------------------- plans
def save_plan(user_id: str, plan: str, nutrition_tip: str = "") -> None:
    with get_session() as s:
        user = s.get(User, user_id)
        if user is None:
            raise KeyError(user_id)
        user.original_plan = plan
        user.nutrition_tip = nutrition_tip


def update_plan(user_id: str, new_plan: str, feedback: str) -> None:
    with get_session() as s:
        user = s.get(User, user_id)
        if user is None:
            raise KeyError(user_id)
        user.updated_plan = new_plan
        user.last_feedback = feedback


def get_original_plan(user_id: str) -> Optional[str]:
    user = get_user(user_id)
    return user.original_plan if user else None


def get_all_plans() -> dict[str, dict[str, Optional[str]]]:
    """Map of user_id -> {'original': ..., 'updated': ...}."""
    return {
        u.user_id: {"original": u.original_plan, "updated": u.updated_plan}
        for u in get_all_users()
    }
