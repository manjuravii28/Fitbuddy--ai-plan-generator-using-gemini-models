"""Deterministic offline plan/tip generators used when Gemini is unavailable."""

_FOCUS = {
    "weight loss": ["Full-body circuit", "Cardio intervals", "Lower body + core",
                    "Active recovery walk", "Upper body + core", "Steady-state cardio", "Rest"],
    "muscle gain": ["Chest + triceps", "Back + biceps", "Legs", "Rest",
                    "Shoulders + core", "Full-body strength", "Rest"],
    "general wellness": ["Full-body strength", "Brisk walk / light cardio", "Mobility + core",
                         "Rest", "Full-body strength", "Recreational activity", "Rest"],
    "flexibility": ["Hips + hamstrings stretch flow", "Light cardio + shoulders mobility",
                    "Yoga flow", "Rest", "Spine + core mobility", "Full-body stretch", "Rest"],
    "endurance": ["Easy aerobic run/bike", "Strength for runners", "Intervals", "Rest",
                  "Tempo effort", "Long easy session", "Rest"],
}
_VOLUME = {"low": ("2 sets of 10", "30 min"), "medium": ("3 sets of 12", "45 min"),
           "high": ("4 sets of 12-15", "60 min")}
_TIPS = {
    "weight loss": "Aim for protein and vegetables at every meal and drink water before snacks to stay full.",
    "muscle gain": "Include protein in your post-workout meal and get 7-9 hours of sleep to recover.",
    "general wellness": "Keep meals balanced, stay hydrated, and take a short walk after eating.",
    "flexibility": "Hydrate well and stretch when muscles are warm, never to the point of sharp pain.",
    "endurance": "Fuel long sessions with carbohydrates and replace fluids and electrolytes afterwards.",
}


def fallback_workout(goal: str, intensity: str) -> str:
    sets, duration = _VOLUME[intensity]
    lines = [f"7-Day {goal.title()} Plan ({intensity} intensity)", ""]
    for i, focus in enumerate(_FOCUS[goal], start=1):
        lines.append(f"Day {i}: {focus}")
        if focus == "Rest":
            lines += ["  - Rest day: light stretching, hydration, good sleep.", ""]
            continue
        lines += [
            "  - Warm-up (5-10 min): easy cardio and dynamic stretches",
            f"  - Main workout ({duration}): exercises for the focus above, {sets} reps each, 60-90s rest",
            "  - Cooldown: 5 min slow walk and static stretching",
            "",
        ]
    lines.append("Note: offline template. Add a GOOGLE_API_KEY for AI-personalised plans.")
    return "\n".join(lines)


def fallback_tip(goal: str) -> str:
    return _TIPS.get(goal, _TIPS["general wellness"])


def fallback_update(plan: str, feedback: str) -> str:
    return (f"{plan}\n\n--- Requested changes (offline mode) ---\n"
            f"Your feedback: {feedback}\n"
            "AI is not configured, so the plan could not be rewritten automatically.")
