"""Quick nutrition / recovery tips with Gemini Flash."""
from . import config
from .ai_client import generate_text
from .fallback import fallback_tip


def generate_nutrition_tip_with_flash(goal: str) -> str:
    prompt = (
        f"Give ONE concise, practical nutrition or recovery tip (max 40 words) for someone "
        f"whose fitness goal is '{goal}'. Plain text, no markdown, no greeting."
    )
    return generate_text(config.GEMINI_FLASH_MODEL, prompt, temperature=0.8) or fallback_tip(goal)
