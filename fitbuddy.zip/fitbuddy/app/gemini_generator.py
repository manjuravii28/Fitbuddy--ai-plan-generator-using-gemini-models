"""7-day workout plan generation with Gemini Pro."""
from . import config
from .ai_client import generate_text
from .fallback import fallback_workout


def build_workout_prompt(age: int, weight: float, goal: str, intensity: str) -> str:
    return f"""Create a personalised 7-day workout plan.

User profile:
- Age: {age}
- Weight: {weight} kg
- Goal: {goal}
- Preferred intensity: {intensity}

Requirements:
- Exactly 7 days, labelled "Day 1" to "Day 7", each with a clear focus (include rest/recovery days sensibly).
- For every training day give: Warm-up (5-10 min), Main workout (exercise, sets x reps or duration, rest intervals), Cooldown / recovery tip.
- Match volume and difficulty to the {intensity} intensity and the goal "{goal}".
- Plain text only: no markdown symbols such as ** or #. Use short lines and dashes for lists.
- Finish with one short line reminding the user to consult a doctor if they have health concerns."""


def generate_workout_gemini(age: int, weight: float, goal: str, intensity: str) -> tuple[str, str]:
    """Return (plan_text, source) where source is 'gemini' or 'offline-fallback'."""
    text = generate_text(config.GEMINI_PRO_MODEL, build_workout_prompt(age, weight, goal, intensity))
    if text:
        return text, "gemini"
    return fallback_workout(goal, intensity), "offline-fallback"
