"""All HTTP routes: HTML pages (Jinja2) and a small JSON API."""
import os
from typing import Optional

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import ValidationError

from . import config, database as db
from .gemini_flash_generator import generate_nutrition_tip_with_flash
from .gemini_generator import generate_workout_gemini
from .schemas import FeedbackRequest, PlanResponse, UserInput
from .updated_plan import update_workout_plan

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
templates = Jinja2Templates(directory=TEMPLATE_DIR)

router = APIRouter()


# ------------------------------------------------------------ helpers
def require_admin(key: Optional[str] = Query(default=None)) -> Optional[str]:
    """If ADMIN_KEY is configured, /view-all-users needs ?key=<ADMIN_KEY>."""
    if config.ADMIN_KEY and key != config.ADMIN_KEY:
        raise HTTPException(status_code=403, detail="Admin key required")
    return key


class NotFound(Exception):
    pass


def create_plan(data: UserInput) -> tuple[str, str, str]:
    """Generate workout + tip, persist everything. Returns (plan, tip, source)."""
    plan, source = generate_workout_gemini(data.age, data.weight, data.goal, data.intensity)
    tip = generate_nutrition_tip_with_flash(data.goal)
    db.save_user(data.user_id, data.username, data.age, data.weight, data.goal, data.intensity)
    db.save_plan(data.user_id, plan, tip)
    return plan, tip, source


def apply_feedback(req: FeedbackRequest) -> tuple[db.User, str, str]:
    """Revise the stored plan. Returns (user, new_plan, source)."""
    user = db.get_user(req.user_id)
    if user is None or not user.original_plan:
        raise NotFound(req.user_id)
    base_plan = user.updated_plan or user.original_plan  # refine the latest version
    new_plan, source = update_workout_plan(base_plan, req.feedback)
    db.update_plan(req.user_id, new_plan, req.feedback)
    return user, new_plan, source


def render_result(request: Request, user: db.User, plan: str, tip: str, message: str = "",
                  source: str = "", status_code: int = 200):
    return templates.TemplateResponse(request, "result.html", {
        "username": user.username, "user_id": user.user_id, "age": user.age,
        "weight": user.weight, "goal": user.goal, "intensity": user.intensity,
        "workout_plan": plan, "nutrition_tip": tip, "message": message, "source": source,
    }, status_code=status_code)


def render_index(request: Request, error: str = "", status_code: int = 200, form: Optional[dict] = None):
    return templates.TemplateResponse(request, "index.html", {
        "error": error, "goals": config.GOALS, "intensities": config.INTENSITIES,
        "form": form or {},
    }, status_code=status_code)


def _validation_message(exc: ValidationError) -> str:
    return "; ".join(f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in exc.errors())


# ------------------------------------------------------------ HTML pages
@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return render_index(request)


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(
    request: Request,
    username: str = Form(...), user_id: str = Form(...), age: str = Form(...),
    weight: str = Form(...), goal: str = Form(...), intensity: str = Form(...),
):
    form = dict(username=username, user_id=user_id, age=age, weight=weight, goal=goal, intensity=intensity)
    try:
        data = UserInput(**form)
    except ValidationError as exc:
        return render_index(request, _validation_message(exc), 422, form)
    plan, tip, source = create_plan(data)
    user = db.get_user(data.user_id)
    return render_result(request, user, plan, tip, source=source)


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(request: Request, user_id: str = Form(...), feedback: str = Form(...)):
    try:
        req = FeedbackRequest(user_id=user_id, feedback=feedback)
    except ValidationError as exc:
        user = db.get_user(user_id.strip())
        if user and user.original_plan:
            return render_result(request, user, user.updated_plan or user.original_plan,
                                 user.nutrition_tip or "", _validation_message(exc), status_code=422)
        return render_index(request, _validation_message(exc), 422)
    try:
        user, new_plan, source = apply_feedback(req)
    except NotFound:
        return render_index(request, f"No plan found for user ID '{req.user_id}'. Generate one first.", 404)
    return render_result(request, user, new_plan, user.nutrition_tip or "",
                         "Your plan has been updated based on your feedback.", source)


@router.get("/plan/{user_id}", response_class=HTMLResponse)
def view_plan(request: Request, user_id: str):
    user = db.get_user(user_id)
    if user is None or not user.original_plan:
        return render_index(request, f"No plan found for user ID '{user_id}'.", 404)
    return render_result(request, user, user.updated_plan or user.original_plan, user.nutrition_tip or "")


@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, key: Optional[str] = Depends(require_admin)):
    return templates.TemplateResponse(request, "all_users.html", {
        "users": db.get_all_users(), "key": key or "",
    })


@router.post("/delete-user/{user_id}")
def delete_user(user_id: str, key: Optional[str] = Depends(require_admin)):
    db.delete_user(user_id)
    url = "/view-all-users" + (f"?key={key}" if key else "")
    return RedirectResponse(url, status_code=303)


# ------------------------------------------------------------ JSON API
@router.post("/api/generate-workout", response_model=PlanResponse)
def api_generate_workout(data: UserInput):
    plan, tip, source = create_plan(data)
    return PlanResponse(user_id=data.user_id, username=data.username, goal=data.goal,
                        intensity=data.intensity, workout_plan=plan, nutrition_tip=tip, ai_source=source)


@router.post("/api/submit-feedback", response_model=PlanResponse)
def api_submit_feedback(req: FeedbackRequest):
    try:
        user, new_plan, source = apply_feedback(req)
    except NotFound:
        raise HTTPException(status_code=404, detail="User or plan not found")
    return PlanResponse(user_id=user.user_id, username=user.username, goal=user.goal,
                        intensity=user.intensity, workout_plan=new_plan,
                        nutrition_tip=user.nutrition_tip or "", ai_source=source)


@router.get("/api/users", dependencies=[Depends(require_admin)])
def api_users():
    return [
        {"user_id": u.user_id, "username": u.username, "age": u.age, "weight": u.weight,
         "goal": u.goal, "intensity": u.intensity, "original_plan": u.original_plan,
         "updated_plan": u.updated_plan}
        for u in db.get_all_users()
    ]


@router.get("/health")
def health():
    from .ai_client import ai_available
    return {"status": "ok", "gemini_configured": ai_available()}
