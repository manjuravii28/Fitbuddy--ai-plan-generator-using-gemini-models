"""Pydantic schemas used to validate user input."""
from typing import Literal
from pydantic import BaseModel, Field, field_validator

Goal = Literal["weight loss", "muscle gain", "general wellness", "flexibility", "endurance"]
Intensity = Literal["low", "medium", "high"]


class UserInput(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    user_id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.-]+$")
    age: int = Field(ge=13, le=100)
    weight: float = Field(gt=20, lt=400, description="Weight in kg")
    goal: Goal
    intensity: Intensity

    @field_validator("username", "user_id", mode="before")
    @classmethod
    def _strip(cls, v):
        return v.strip() if isinstance(v, str) else v

    @field_validator("goal", "intensity", mode="before")
    @classmethod
    def _normalise(cls, v):
        return v.strip().lower() if isinstance(v, str) else v


class FeedbackRequest(BaseModel):
    user_id: str = Field(min_length=1, max_length=64)
    feedback: str = Field(min_length=3, max_length=500)

    @field_validator("user_id", "feedback", mode="before")
    @classmethod
    def _strip(cls, v):
        return v.strip() if isinstance(v, str) else v


class PlanResponse(BaseModel):
    user_id: str
    username: str
    goal: str
    intensity: str
    workout_plan: str
    nutrition_tip: str
    ai_source: str  # "gemini" or "offline-fallback"
