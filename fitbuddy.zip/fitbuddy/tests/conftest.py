import os, sys, tempfile

# Configure BEFORE the app is imported: temp DB and no Gemini key (offline fallback).
_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["GOOGLE_API_KEY"] = ""
os.environ["ADMIN_KEY"] = ""
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
