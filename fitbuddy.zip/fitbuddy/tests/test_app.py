import pytest
from fastapi.testclient import TestClient

from app.main import app

FORM = dict(username="Asha", user_id="asha01", age="25", weight="60",
            goal="muscle gain", intensity="high")


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:   # runs lifespan -> creates tables
        yield c


def test_home_page(client):
    r = client.get("/")
    assert r.status_code == 200 and "Generate Plan" in r.text


def test_generate_workout_html(client):
    r = client.post("/generate-workout", data=FORM)
    assert r.status_code == 200
    assert "Day 1" in r.text and "Day 7" in r.text
    assert "asha01" in r.text and "protein" in r.text.lower()


def test_validation_error(client):
    r = client.post("/generate-workout", data={**FORM, "age": "5", "user_id": "bad id!"})
    assert r.status_code == 422 and "error" in r.text


def test_feedback_updates_plan(client):
    client.post("/generate-workout", data=FORM)
    r = client.post("/submit-feedback", data={"user_id": "asha01", "feedback": "more cardio please"})
    assert r.status_code == 200 and "updated" in r.text
    page = client.get("/view-all-users").text
    assert "Updated plan" in page and "more cardio please" in page


def test_feedback_unknown_user(client):
    r = client.post("/submit-feedback", data={"user_id": "ghost", "feedback": "more cardio"})
    assert r.status_code == 404


def test_json_api(client):
    body = dict(username="Ben", user_id="ben_2", age=40, weight=82.5,
                goal="weight loss", intensity="low")
    r = client.post("/api/generate-workout", json=body)
    assert r.status_code == 200 and r.json()["ai_source"] == "offline-fallback"
    r = client.post("/api/submit-feedback", json={"user_id": "ben_2", "feedback": "add yoga"})
    assert r.status_code == 200 and "yoga" in r.json()["workout_plan"]
    assert len(client.get("/api/users").json()) >= 2


def test_html_is_escaped(client):
    client.post("/generate-workout", data={**FORM, "user_id": "xss1", "username": "<script>alert(1)</script>"})
    assert "<script>alert(1)</script>" not in client.get("/view-all-users").text


def test_delete_user(client):
    client.post("/delete-user/xss1", follow_redirects=False)
    assert "xss1" not in client.get("/view-all-users").text
